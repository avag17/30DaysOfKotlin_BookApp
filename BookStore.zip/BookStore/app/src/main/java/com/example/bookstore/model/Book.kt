package com.example.bookstore.model

data class Book(
    val bookId:String,
    val bookname:String,
    val bookAuthor:String,
    val bookRating:String,
    val bookPrice:String,
    val bookImg:String
)