package com.example.bookstore.fragment
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings

import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.bookstore.R
import com.example.bookstore.adapter.DashboardRecyclerAdapter
import com.example.bookstore.model.Book
import com.example.bookstore.util.ConnectionManager
import org.json.JSONException
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap


class DashboardFragment : Fragment() {

    lateinit var recyclerView: RecyclerView
    lateinit var layoutmanager:RecyclerView.LayoutManager
    lateinit var btnCheckInternet: Button

    lateinit var recyclerAdapter: DashboardRecyclerAdapter

    lateinit var progressLayout:RelativeLayout
    lateinit var progressBar:ProgressBar

    /*
    This is Static Way To add elements in recyclerView------

    val bookInfoList= arrayListOf<Book>(
        Book("P.S. I love You", "Cecelia Ahern", "Rs. 299", "4.5", R.drawable.ps_ily),
        Book("The Great Gatsby", "F. Scott Fitzgerald", "Rs. 399", "4.1", R.drawable.great_gatsby),
        Book("Anna Karenina", "Leo Tolstoy", "Rs. 199", "4.3", R.drawable.anna_kare),
        Book("Madame Bovary", "Gustave Flaubert", "Rs. 500", "4.0", R.drawable.madame),
        Book("War and Peace", "Leo Tolstoy", "Rs. 249", "4.8", R.drawable.war_and_peace),
        Book("Lolita", "Vladimir Nabokov", "Rs. 349", "3.9", R.drawable.lolita),
        Book("Middlemarch", "George Eliot", "Rs. 599", "4.2", R.drawable.middlemarch),
        Book("The Adventures of Huckleberry Finn", "Mark Twain", "Rs. 699", "4.5", R.drawable.adventures_finn),
        Book("Moby-Dick", "Herman Melville", "Rs. 499", "4.5", R.drawable.moby_dick),
        Book("The Lord of the Rings", "J.R.R Tolkien", "Rs. 749", "5.0", R.drawable.lord_of_rings)
    )*/

    val bookInfoList= arrayListOf<Book>()
    val bookInfoList2= arrayListOf<Book>()

    var ratingComparator=Comparator<Book> { book1, book2 ->
        if(book1.bookRating.compareTo(book2.bookRating, true)==0)
            book1.bookname.compareTo(book2.bookname, true)
        else
            book1.bookRating.compareTo(book2.bookRating, true)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_dashboard, container, false)

        setHasOptionsMenu(true)

        recyclerView= view.findViewById(R.id.recyclerView)

        progressLayout=view.findViewById(R.id.progressLayout)
        progressBar=view.findViewById(R.id.progressBar)

        progressLayout.visibility=View.VISIBLE

        //Checking Internet Connnection(From Button) From Here
        /*This Button Click Can Be Removed Because we Already are checking the connection
        btnCheckInternet=view.findViewById(R.id.btnCheckInternet)
        btnCheckInternet.setOnClickListener {
            if(ConnectionManager().checkConnectivity(activity as Context)){
                val dialog=AlertDialog.Builder(activity as Context)
                dialog.setTitle("Success")
                dialog.setMessage("Internet Connection Found")
                dialog.setPositiveButton("Ok"){text,listner->

                }
                dialog.setNegativeButton("Cancel"){text,listner->

                }
                dialog.create()
                dialog.show()
            }else{
                val dialog=AlertDialog.Builder(activity as Context)
                dialog.setTitle("Failure")
                dialog.setMessage("Internet Connection Not Found")
                dialog.setPositiveButton("Ok"){text,listner->

                }
                dialog.setNegativeButton("Cancel"){text,listner->

                }
                dialog.create()
                dialog.show()
            }
        }
        //Till Here
        */

        layoutmanager= LinearLayoutManager(activity)

       /* This Part is For Static Data Entry
       For Dynamic i.e. using internet move this code below as shown


       recyclerAdapter= DashboardRecyclerAdapter(
            activity as Context,
            bookInfoList
        )

        recyclerView.adapter=recyclerAdapter
        recyclerView.layoutManager=layoutmanager
        recyclerView.setHasFixedSize(true)

        recyclerView.addItemDecoration(
            DividerItemDecoration(
                recyclerView.context,(layoutmanager as LinearLayoutManager).orientation
            )
        )*/

        val queue= Volley.newRequestQueue(activity as Context)
        val url="http://13.235.250.119/v1/book/fetch_books/"

        if(ConnectionManager().checkConnectivity(activity as Context)) {
            val jsonObjectRequest = object : JsonObjectRequest(Method.GET, url, null,
                Response.Listener {
                    //here we Handle The Response
                    //This is used to check the jsonObject In LogCat window----->println("Response is $it")
                    try {
                        progressLayout.visibility=View.GONE
                        val success = it.getBoolean("success")
                        if (success) {
                            val data = it.getJSONArray("data")
                            for (i in 0 until data.length()) {
                                val bookJsonObject = data.getJSONObject(i)
                                val bookObject = Book(
                                    bookJsonObject.getString("book_id"),
                                    bookJsonObject.getString("name"),
                                    bookJsonObject.getString("author"),
                                    bookJsonObject.getString("rating"),
                                    bookJsonObject.getString("price"),
                                    bookJsonObject.getString("image")
                                )
                                bookInfoList.add(bookObject)
                                bookInfoList2.addAll(bookInfoList)
                                recyclerAdapter = DashboardRecyclerAdapter(
                                    activity as Context,
                                    bookInfoList2
                                )

                                recyclerView.adapter = recyclerAdapter
                                recyclerView.layoutManager = layoutmanager
                                recyclerView.setHasFixedSize(true)

                                /*This is used only if CardView in xml is not used else remove it
                                recyclerView.addItemDecoration(
                                    DividerItemDecoration(
                                        recyclerView.context,
                                        (layoutmanager as LinearLayoutManager).orientation
                                    )
                                )*/
                            }
                        } else {
                            if (activity != null)
                                Toast.makeText(activity as Context,"Error Occured",Toast.LENGTH_SHORT).show()
                        }
                    }catch (e:JSONException){
                        Toast.makeText(activity as Context, "Some Exception Occured", Toast.LENGTH_SHORT).show()
                    }

                }, Response.ErrorListener {
                    //here we Handle The Error
                    if(activity!=null)
                        Toast.makeText(activity as Context, "Volley Error Occured", Toast.LENGTH_SHORT).show()
                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-type"] = "application/json"
                    headers["token"] = "8bb498646020f0"       //Unique For EveryOne
                    //This is provided in video--"9bf534118365f1"
                    // This is mine----"8bb498646020f0"

                    return headers
                }
            }
            queue.add(jsonObjectRequest)
        }else{
            val dialog=AlertDialog.Builder(activity as Context)
            dialog.setTitle("Failure")
            dialog.setMessage("Internet Connection Not Found")
            dialog.setPositiveButton("Open Settings"){text,listner->
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                activity?.finish()
            }
            dialog.setNegativeButton("Exit"){text,listner->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }

        return view
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater?) {
        inflater?.inflate(R.menu.menu_dashboard,menu)
        val searchItem=menu.findItem(R.id.search)
        if(searchItem!=null) {
            val searchView = searchItem.actionView as SearchView
            val editext = searchView.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)
            editext.hint = "Search here..."
            searchView.setOnQueryTextListener(object: SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(query: String?): Boolean {
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    if(newText!!.isNotEmpty()){
                        bookInfoList2.clear()
                        val search=newText.toLowerCase()
                        bookInfoList.forEach {
                            if(it.bookname.toLowerCase().contains(search)){
                                bookInfoList2.add(it)
                            }
                        }
                        recyclerView.adapter?.notifyDataSetChanged()
                    }
                    else{
                        bookInfoList2.clear()
                        bookInfoList2.addAll(bookInfoList)
                        recyclerView.adapter?.notifyDataSetChanged()
                    }
                   return true
                }

            })
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id=item?.itemId
        if(id==R.id.action_sort){
            Collections.sort(bookInfoList,ratingComparator)
            bookInfoList.reverse()

        }

        recyclerAdapter.notifyDataSetChanged()
        return super.onOptionsItemSelected(item)
    }

}
